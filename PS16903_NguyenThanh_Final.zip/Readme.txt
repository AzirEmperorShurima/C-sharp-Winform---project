net 4.6
ado.net

tài khoản admin 
EMAIL: akhucute5@gmail.com
MK: matkhau123